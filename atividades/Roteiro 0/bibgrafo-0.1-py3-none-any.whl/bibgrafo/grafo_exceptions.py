class VerticeInvalidoException(Exception):
    pass

class ArestaInvalidaException(Exception):
    pass